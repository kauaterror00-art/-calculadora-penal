// Função serverless (Vercel): recebe o pedido e registra no canal de logs do Discord.
// O link do webhook fica na variável de ambiente DISCORD_WEBHOOK_URL (nunca no site).
const brl = (v) => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v);
const clean = (s, max) => String(s ?? "").replace(/[`@*_~|>]/g, "").slice(0, max).trim();

module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ error: "method" });
  const url = process.env.DISCORD_WEBHOOK_URL;
  if (!url) return res.status(500).json({ error: "config" });

  const body = typeof req.body === "string" ? JSON.parse(req.body || "{}") : req.body || {};
  const discord = clean(body.discord, 40);
  const items = Array.isArray(body.items) ? body.items.slice(0, 30) : [];
  if (!discord || !items.length) return res.status(400).json({ error: "dados" });

  let total = 0, quote = false;
  const lines = items.map((i) => {
    const qty = Math.min(Math.max(parseInt(i.qty, 10) || 1, 1), 99);
    const priced = typeof i.price === "number" && isFinite(i.price) && i.price >= 0;
    if (priced) total += i.price * qty; else quote = true;
    return `${qty}x ${clean(i.name, 100)} (${clean(i.category, 30)}) — ${priced ? brl(i.price * qty) : "Sob orçamento"}`;
  });

  const payload = {
    allowed_mentions: { parse: [] },
    embeds: [{
      title: "🛒 Novo pedido na loja",
      color: 0x8b3dff,
      fields: [
        { name: "Cliente (Discord)", value: discord },
        { name: "Itens", value: lines.join("\n").slice(0, 1000) },
        { name: "Total", value: `${brl(total)}${quote ? " + itens sob orçamento" : ""}\n(preços informados pelo site, confirme no atendimento)` },
      ],
      timestamp: new Date().toISOString(),
    }],
  };

  try {
    const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    if (!r.ok) return res.status(502).json({ error: "discord" });
    return res.status(200).json({ ok: true });
  } catch (e) {
    return res.status(502).json({ error: "discord" });
  }
};
