# Nine Studio — loja + log de pedidos no Discord

Site estático (`index.html`) + função serverless (`api/pedido.js`) que registra cada pedido enviado no seu canal de logs do Discord.

## Como publicar na Vercel
1. No Discord: canal de logs > Editar canal > Integrações > Webhooks > Novo webhook > Copiar URL.
2. Suba esta pasta para um repositório no GitHub e importe o repositório na Vercel (ou use `vercel` no terminal).
3. Na Vercel: Settings > Environment Variables > crie `DISCORD_WEBHOOK_URL` com o link copiado. Faça um novo deploy.
4. Teste: adicione um produto ao carrinho, informe um usuário do Discord e clique em "Enviar pedido ao atendimento".

## Importante
- Nunca coloque o link do webhook no `index.html` nem no GitHub. Ele só existe na variável de ambiente.
- Se o link vazar, apague o webhook no Discord e crie outro.
- Os preços do log vêm do navegador do cliente; confirme sempre o valor no atendimento.
